﻿module.exports = {
    'secret': 'supersecret'
};