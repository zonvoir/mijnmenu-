export class User {
    id: number;
    email: string;
    password: string;
    fullName: string;
    _id: string;
    FirstName: string;
    LastName: string;
    EmailAddress: string;
    Password: string;
    FireBaseId: string;
    RoleId: string;
    CreatedDate: Date;
    ModifiedDate: Date;
    Subscription: string;
}
