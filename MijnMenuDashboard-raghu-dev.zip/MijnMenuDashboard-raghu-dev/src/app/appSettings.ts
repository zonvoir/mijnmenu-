export class AppSettings {
    //public static API_ENDPOINT = 'http://localhost:3000';
    //public static API_ENDPOINT = 'http://112.196.24.205:3000';
  public static API_ENDPOINT = 'http://134.209.87.18';
} 
