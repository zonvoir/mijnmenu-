export class Table {
    _id: String;
    Name: String;
    RestaurantId: String;
    RestaurantName: String;
    TableType: String;
    TableStatus: String;
    Seats: String;
    CreatedDate: Date;
    ModifiedDate: Date;
}
