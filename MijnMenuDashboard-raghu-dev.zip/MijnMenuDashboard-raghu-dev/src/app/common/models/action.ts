// Actions you can take on the App
export enum Action {
    JOINED,
    LEFT,
    RENAME
}