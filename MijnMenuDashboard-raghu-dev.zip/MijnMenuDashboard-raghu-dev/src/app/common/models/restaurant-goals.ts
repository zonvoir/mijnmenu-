export class RestaurantGoals {
    _id: String;
    RevenueGoal: Number;
    CashierGoal: Number;
    CustomerGoal: Number;
    RestaurantId: Number;
    Month: Number;
    CreatedDate: Date;
    Description: String;
    ModifiedDate: Date;
}
