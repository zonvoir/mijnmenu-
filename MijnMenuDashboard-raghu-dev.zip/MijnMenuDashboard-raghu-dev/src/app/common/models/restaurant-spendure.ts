export class RestaurantSpendure {
    _id: String;
    RestaurantId: Number;
    OrderId: Number;
    Amount: Number;
    UserId: Number;
    Status: String;
    CreatedDate: Date;
    ModifiedDate: Date;
}
