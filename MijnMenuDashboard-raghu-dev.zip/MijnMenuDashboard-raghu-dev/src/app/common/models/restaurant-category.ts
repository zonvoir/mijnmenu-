export class RestaurantCategory {
    _id: String;
    Name: String;
    CreatedDate: Date;
    Description: String;
    ModifiedDate: Date;
}
