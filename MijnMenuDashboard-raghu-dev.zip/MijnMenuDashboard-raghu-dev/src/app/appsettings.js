"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AppSettings = /** @class */ (function () {
    function AppSettings() {
    }
   // public static API_ENDPOINT = 'http://localhost:3000';
     //AppSettings.API_ENDPOINT = 'http://localhost:3000';
     AppSettings.API_ENDPOINT = 'http://134.209.87.18';
     
   //AppSettings.API_ENDPOINT = 'http://112.196.24.205:3000';
    return AppSettings;
}());
exports.AppSettings = AppSettings;
//# sourceMappingURL=appsettings.js.map
